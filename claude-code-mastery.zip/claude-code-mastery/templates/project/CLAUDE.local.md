# My Local Preferences

> Personal preferences for THIS project only.
> This file is gitignored - won't be shared with team.

## Current Focus

- [What I'm working on this week]

## Personal Shortcuts

- [Any personal workflow notes]

## Temporary Overrides

- [Any temporary deviations from team standards]

## Notes

- [Personal notes about the project]
